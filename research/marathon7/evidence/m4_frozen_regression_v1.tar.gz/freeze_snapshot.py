import ast,gzip,hashlib,io,json,os,stat,tarfile,time
from pathlib import Path
ROOT=Path('/workspace/efficient-matrix-multiplication')
OUT=ROOT/'artifacts/marathon7_20261103T122417Z/m4-frozen-regression-v1'
DIRS=('mmsearch','scripts','tests','native')
def sha(data):return hashlib.sha256(data).hexdigest()
def files():
 return sorted(p for name in DIRS for p in (ROOT/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo'))
def read(p):
 a=p.stat();data=p.read_bytes();b=p.stat()
 if (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)!=(b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns,b.st_ctime_ns):raise RuntimeError('changing file: '+str(p))
 return data,stat.S_IMODE(a.st_mode)
for attempt in range(4):
 try:
  paths=files();payload={str(p.relative_to(ROOT)):read(p) for p in paths}
  for name,(data,_) in payload.items():
   if name.endswith('.py'):ast.parse(data,filename=name)
  if paths!=files():raise RuntimeError('source file set changed')
  for p in paths:
   if read(p)[0]!=payload[str(p.relative_to(ROOT))][0]:raise RuntimeError('source content changed: '+str(p))
  break
 except (RuntimeError,SyntaxError) as e:
  if attempt==3:raise
  print('Snapshot retry:',e,flush=True)
else:raise RuntimeError('no stable source snapshot')
OUT.mkdir(exist_ok=False);source=OUT/'source';source.mkdir()
for name,(data,mode) in payload.items():
 p=source/name;p.parent.mkdir(exist_ok=True,parents=True);p.write_bytes(data);p.chmod(0o555 if mode&0o111 else 0o444)
assets={}
for p in ROOT.iterdir():
 if p.name in DIRS or p.name=='.git':continue
 (source/p.name).symlink_to(p,target_is_directory=p.is_dir());assets[p.name]=str(p)
manifest=dict(format='marathon7-frozen-regression-v1',source_root=str(ROOT),snapshot_root=str(source),files={n:dict(sha256=sha(d),bytes=len(d),mode=oct(m)) for n,(d,m) in payload.items()},file_count=len(payload),python_ast_parsed=sum(n.endswith('.py') for n in payload),exclusions=['__pycache__ directories and .pyc/.pyo only; no source/test/fixture exclusions'],asset_symlinks=assets,asset_policy='Existing root assets and artifact binaries are referenced for reads; no artifact tree copy or new search. Code/test/fixture/native files are byte-isolated.',captured_epoch=time.time())
(OUT/'snapshot-manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(status='FROZEN_SOURCE_READY',file_count=len(payload),python_ast_parsed=manifest['python_ast_parsed'],bytes=sum(len(d) for d,m in payload.values()),manifest_sha256=sha((OUT/'snapshot-manifest.json').read_bytes()),out=str(OUT))),flush=True)
