# Frozen M4 regression snapshot

The source directory contains copied mmsearch, scripts, tests (including all fixtures), and native files. No source or test files were excluded. Python bytecode caches were excluded. Every Python file passed AST parsing during stable capture; each live file's stat signature and bytes were checked again before publication.

The runner imports only copied source and the external XOR dependency directory. Its main guard supports multiprocessing spawn. Before and after discovery it checks every copied file, including native executables and non-Python fixtures, against snapshot-manifest.json.

Repository root assets, artifacts and .xor-deps are symlinks to the original repository, for existing inputs and frozen native binaries. The artifact tree is not duplicated. Those external dependencies are not portable within this archive; rebind these asset symlinks to the same assets when moving the snapshot. No production queue or search is launched.

Reproduce from the original environment with:

```
python3 -B scripts/limited_worker.py --cpu 3 --memory-mb 3072 --seconds 300 --prefix /tmp/m4-regression-replay -- python3 -B /absolute/path/to/this/snapshot/runner.py
```

The limited worker must come from the same tested source. The full regression output and launcher result record the actual run, resource use, test result and source stability. Live repository edits after snapshot capture do not enter this test run.
