"""Bounded cyclic native phases from independently verified polarized seeds.

Branch progress below rank 98 is distinct from a new matrix-multiplication
record: only an independently verified rank <=92 certificate meets the target.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import random
import signal
import subprocess
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from mmsearch.cube_polarization import orbit_inventory
from mmsearch.native_bridge import _freeze, _json_bytes, _read_terms, canonical_terms, term_set_sha256
from mmsearch.search import encode_candidate, is_cyclic, orbit_counts
from mmsearch.verify import verify_candidate


def save(path,value):
    path = Path(path)
    tmp = path.with_name(path.name+".tmp")
    tmp.write_bytes(_json_bytes(value))
    tmp.replace(path)


def save_best(output_dir,record):
    if not record:
        return
    path = Path(output_dir)/'best_verified.json'
    if not path.exists() or record['rank'] < json.loads(path.read_text())['rank']:
        save(path,record)


def drain_verified(prefix,output_dir,metadata,*,n=5,target=92,max_rank=107,
                   seen=None,counts=None,per_bucket=64):
    """Drain final or periodic best/current/archive; never miss fast success."""
    prefix,output_dir = Path(prefix),Path(output_dir)
    seen = seen if seen is not None else set()
    counts = counts if counts is not None else Counter()
    paths = [prefix.with_suffix('.best.txt'),prefix.with_suffix('.current.txt'),
             *sorted(prefix.with_suffix('.archive').glob('*.txt'))]
    winner = (output_dir/'WINNER.json').exists()
    best_record = None
    for path in paths:
        if not path.exists():
            continue
        terms = _read_terms(path,n)
        rank = len(terms)
        if rank > max_rank or not is_cyclic(terms):
            raise ValueError('native checkpoint violates cyclic/rank limits')
        if rank > 98:
            continue
        h = term_set_sha256(terms)
        if h in seen:
            continue
        # Keep a bounded portfolio in each branch-progress range, retaining all targets.
        bucket = '<=92' if rank <= target else ('93-95' if rank <= 95 else '96-98')
        if rank > target and counts[bucket] >= per_bucket and path != paths[0]:
            continue
        value = encode_candidate(terms,n,method='polarized-native-cyclic-checkpoint',parent=metadata,
                                 term_set_sha256=h,orbit_profile=orbit_counts(terms),
                                 orbit_inventory=orbit_inventory(terms),
                                 status='verified_target' if rank <= target else 'branch_progress')
        report = verify_candidate(value,random_trials=0)
        if not report['valid']:
            raise RuntimeError('independent exact verification rejected native checkpoint')
        payload = _json_bytes(value)
        frozen = _freeze(output_dir/'verified'/(h+'.json'),payload)
        verification = _freeze(output_dir/'verification'/(h+'.verification.json'),_json_bytes(report))
        digest = hashlib.sha256(payload).hexdigest()
        _freeze(output_dir/'verification'/(h+'.sha256'),(digest+'  '+frozen.name+'\n').encode())
        seen.add(h);counts[bucket] += 1
        record = dict(path=str(frozen),verification_path=str(verification),sha256=digest,rank=rank,
                      orbit_profile=orbit_counts(terms),bucket=bucket)
        if path == paths[0]:
            best_record = record
        if rank <= target and not winner:
            _freeze(output_dir/'WINNER.json',payload)
            _freeze(output_dir/'WINNER.verification.json',_json_bytes(report))
            _freeze(output_dir/'WINNER.verify.py',Path(__file__).resolve().parents[1].joinpath('mmsearch/verify.py').read_bytes())
            winner = True
            break
    return dict(winner=winner,best_record=best_record,verified=len(seen),buckets=dict(counts))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--binary',type=Path,required=True)
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--pool',type=Path,required=True)
    p.add_argument('--output-dir',type=Path,required=True)
    p.add_argument('--seconds',type=float,required=True)
    p.add_argument('--phase-seconds',type=float,default=600)
    p.add_argument('--seed',type=int,default=0)
    p.add_argument('--target',type=int,default=92)
    p.add_argument('--archive-size',type=int,default=32)
    p.add_argument('--cyclic',action='store_true',default=True)
    args = p.parse_args()
    if args.seconds <= 0 or args.phase_seconds <= 0 or not 1 <= args.archive_size <= 32:
        p.error('positive budgets and archive-size <=32 required')
    args.output_dir.mkdir(parents=True,exist_ok=False)
    sources = sorted(set([args.input.resolve(),*args.pool.resolve().glob('*.json')]))
    rng = random.Random(args.seed);rng.shuffle(sources)
    candidates = []
    for source in sources:
        raw = source.read_bytes();value = json.loads(raw)
        terms = canonical_terms(value);n = value['dimension']
        if n != 5 or len(terms) != 98 or orbit_counts(terms)['fixed_cubes'] != 2 or not is_cyclic(terms):
            raise ValueError('campaign requires cyclic rank98 seeds with two fixed cubes')
        if not verify_candidate(encode_candidate(terms,n),random_trials=0)['valid']:
            raise ValueError('invalid polarized source')
        candidates.append((source,raw,terms))
    binary_sha = hashlib.sha256(args.binary.read_bytes()).hexdigest()
    wrapper_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    stop = False
    def stopped(signum,frame):
        nonlocal stop
        stop = True
    signal.signal(signal.SIGTERM,stopped);signal.signal(signal.SIGINT,stopped)
    deadline = time.monotonic()+args.seconds
    seen,counts,phases = set(),Counter(),[]
    while not stop and time.monotonic() < deadline:
        phase = len(phases);source,raw,terms = candidates[phase%len(candidates)]
        folder = args.output_dir/f'phase-{phase:03d}';folder.mkdir()
        masks = _freeze(folder/'input.txt',''.join(f'{a} {b} {c}\n' for a,b,c in terms).encode())
        prefix = folder/'walk'
        budget = min(args.phase_seconds,max(0,deadline-time.monotonic()))
        maximum = len(terms)+(3,6,9)[phase%3]
        command = [str(args.binary.resolve()),'--input',str(masks),'--output',str(prefix),'--n','5',
                   '--target',str(args.target),'--max-rank',str(maximum),'--seed',str(args.seed+phase*1009),
                   '--steps','1000000000000','--seconds',str(budget),'--checkpoint-seconds','15',
                   '--archive-size',str(args.archive_size),'--archive-every','1000',
                   '--plus-every',str((100,250,1000)[phase%3]),
                   '--restart-every',str((50000,200000,1000000)[phase%3]),'--cyclic']
        meta = dict(phase=phase,source=str(source),source_sha256=hashlib.sha256(raw).hexdigest(),
                    binary_sha256=binary_sha,wrapper_sha256=wrapper_sha,command=command,
                    initial_rank=len(terms),initial_profile=orbit_counts(terms),
                    initial_inventory=orbit_inventory(terms),max_rank=maximum,
                    note='C3 closure enforced; fixed cube inventory is not constrained')
        _freeze(folder/'manifest.json',_json_bytes(meta))
        with (folder/'worker.log').open('x') as log:
            process = subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)
            last_scan = 0
            try:
                while process.poll() is None and not stop:
                    if time.monotonic()-last_scan >= 15:
                        last_scan = time.monotonic()
                        result = drain_verified(prefix,args.output_dir,meta,max_rank=maximum,seen=seen,counts=counts,target=args.target)
                        save_best(args.output_dir,result['best_record'])
                        if prefix.with_suffix('.stats.json').exists():
                            stats = json.loads(prefix.with_suffix('.stats.json').read_text())
                            save(args.output_dir/'latest_stats.json',dict(phase=phase,stats=stats,verified=result))
                        if result['winner']:
                            stop = True
                    time.sleep(.2)
            finally:
                if process.poll() is None:
                    process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill();process.wait()
        if process.returncode != 0:
            raise RuntimeError(f'native polarized phase failed: {folder}')
        result = drain_verified(prefix,args.output_dir,meta,max_rank=maximum,seen=seen,counts=counts,target=args.target)
        save_best(args.output_dir,result['best_record'])
        stop = stop or result['winner']
        stats = json.loads(prefix.with_suffix('.stats.json').read_text())
        meta.update(exit_code=process.returncode,final_stats=stats,verified=result)
        phases.append(meta)
        save(args.output_dir/'latest_stats.json',dict(phase=phase,stats=stats,verified=result))
        save(args.output_dir/'summary.json',dict(phases=phases,verified=len(seen),buckets=dict(counts),winner=result['winner']))
    print(json.dumps(dict(phases=len(phases),verified=len(seen),buckets=dict(counts),stopped=stop)))


if __name__ == '__main__':
    main()
