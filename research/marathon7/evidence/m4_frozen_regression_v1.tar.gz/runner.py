"""Run frozen full unittest discovery; safe to re-import for spawned workers."""
def main():
    import hashlib,json,os,sys,time,unittest
    from pathlib import Path
    OUT=Path(__file__).resolve().parent;ROOT=OUT/'source'
    os.chdir(ROOT)
    live=Path('/workspace/efficient-matrix-multiplication')
    sys.path[:]=[str(ROOT),str(ROOT/'.xor-deps')]+[p for p in sys.path if p and not str(p).startswith(str(live))]
    os.environ['PYTHONPATH']=os.pathsep.join([str(ROOT),str(ROOT/'.xor-deps')])
    os.environ['PYTHONDONTWRITEBYTECODE']='1'
    frozen=ROOT/'artifacts/rl_campaign42_20261103T033116Z'
    binaries=dict(ONECOSET43_BINARY=frozen/'native-onecoset43-ready-v2/native/onecoset43',DWELL42_BASELINE_BINARY=frozen/'dwell42-ready-v1/native/baseline-worker',DWELL42_BINARY=frozen/'dwell42-ready-v1/native/dwell-worker',BURST42_BASELINE_BINARY=frozen/'plus-burst42-pilot-ready-v1/native/dwell-baseline-worker',BURST42_BINARY=frozen/'plus-burst42-pilot-ready-v1/native/plus-burst-worker')
    os.environ.update({k:str(v) for k,v in binaries.items()})
    def hashes():
        return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for directory in ('mmsearch','scripts','tests','native') for p in sorted((ROOT/directory).rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc','.pyo')}
    manifest=json.loads((OUT/'snapshot-manifest.json').read_text());expected={p:r['sha256'] for p,r in manifest['files'].items()}
    before=hashes();(OUT/'hashes-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
    if before!=expected:raise RuntimeError('snapshot pre-run bytes differ from capture manifest')
    import pycryptosat,pysat
    print('Real XOR:',pycryptosat.__file__,'PySAT:',pysat.__file__,flush=True)
    print('Frozen binaries:',json.dumps({k:dict(path=str(v),sha256=hashlib.sha256(v.read_bytes()).hexdigest()) for k,v in binaries.items()},sort_keys=True),flush=True)
    started=time.monotonic();suite=unittest.defaultTestLoader.discover('tests');result=unittest.TextTestRunner(verbosity=2).run(suite)
    after=hashes();(OUT/'hashes-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
    changes={p:dict(before=before.get(p),after=after.get(p)) for p in sorted(before.keys()|after.keys()) if before.get(p)!=after.get(p)}
    report=dict(tests_run=result.testsRun,failures=[(str(t),s) for t,s in result.failures],errors=[(str(t),s) for t,s in result.errors],skipped=[(str(t),s) for t,s in result.skipped],expected_failures=[(str(t),s) for t,s in result.expectedFailures],unexpected_successes=[str(t) for t in result.unexpectedSuccesses],successful=result.wasSuccessful() and not changes,elapsed_seconds=time.monotonic()-started,source_hash_count_before=len(before),source_hash_count_after=len(after),source_changes=changes,snapshot_manifest_sha256=hashlib.sha256((OUT/'snapshot-manifest.json').read_bytes()).hexdigest(),code_isolated_from_live_edits=True)
    report['passes']=result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped)-len(result.expectedFailures)-len(result.unexpectedSuccesses)
    (OUT/'summary.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    print(json.dumps(report),flush=True)
    return 0 if report['successful'] else 1

if __name__=='__main__':
    raise SystemExit(main())
