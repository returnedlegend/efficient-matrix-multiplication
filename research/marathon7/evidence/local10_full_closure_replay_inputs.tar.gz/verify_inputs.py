from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
meta=json.loads((root/'REPLAY-INPUTS.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for source,expected in meta['source_sha256'].items():assert sha(root/f'source-{source}.json')==expected
assert sha(root/'survivors.tsv.gz')==meta['input_catalogue_sha256']
for name,expected in meta['runtime_file_sha256'].items():assert sha(root/'runtime'/name)==expected
print('All archived source/catalogue/runtime hashes match; no decoder called.')
